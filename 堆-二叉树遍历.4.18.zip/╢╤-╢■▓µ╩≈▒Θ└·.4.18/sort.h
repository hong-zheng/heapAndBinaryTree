#include "heap.h"

void heapSort(int* array, int n);